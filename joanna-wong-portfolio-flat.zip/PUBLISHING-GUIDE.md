# Publishing this site on GitHub Pages

Free. Your site will live at `https://YOUR-USERNAME.github.io`.

## 1. Create a GitHub account
Sign up at github.com. Your username becomes your web address, so something like
`joannawong` reads better on a resume than a nickname.

## 2. Create the repository
1. Click the **+** in the upper-right corner, then **New repository**.
2. Repository name: `YOUR-USERNAME.github.io` (all lowercase, your exact username).
3. Visibility: **Public**.
4. Click **Create repository**.

## 3. Upload the site
1. On the new repository page, click **uploading an existing file** (or **Add file > Upload files**).
2. Unzip the site, open the folder, select everything INSIDE it
   (every file; there are no subfolders) and drag it into the browser.
   Do not drag the outer folder itself: `index.html` must sit at the top level.
3. Click **Commit changes**.

## 4. Turn on Pages
1. In the repository, click **Settings**.
2. In the sidebar, click **Pages**.
3. Under **Build and deployment**, set **Source** to **Deploy from a branch**.
4. Set **Branch** to `main` and the folder to `/ (root)`, then click **Save**.

Open `https://YOUR-USERNAME.github.io`. Publishing can take up to 10 minutes.

## Adding photos
1. Rename each photo to the name shown in its placeholder box, for example `kicksense-1.jpg` (full list in `PHOTO-NAMES.txt`).
2. In the repository, click **Add file > Upload files**, drag the photos in, and commit. They go in the same place as `index.html`, not in a folder.

## Adding your resume
Upload a file named `resume.pdf` next to `index.html`. A Resume link then appears in the menu.

## Editing text later
Open the page's file in the repository (for example `kicksense.html` or `about.html`), click the pencil icon, change the text, and click **Commit changes**.

## If something looks wrong
- Page not found: the repository name must match your username exactly, and `index.html` must be at the top level.
- No styling: `style.css` was not uploaded next to `index.html`.
- A photo is not showing: the file name must match exactly, including lowercase and `.jpg`.
